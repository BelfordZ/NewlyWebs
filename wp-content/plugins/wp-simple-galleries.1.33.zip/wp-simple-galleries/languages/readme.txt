== For Translators ==

If you have created your own translation, or have an update of an existing one, please send it to Maca134 <maca134@gmail.com> so that I can bundle it into the next release of WP Simple Galleries.

Thank you.